#!/usr/bin/env python3
import os
import socket
import serial
import time
import json
import logging
import paho.mqtt.client as mqtt
from datetime import datetime, timezone

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s"
)
logging.getLogger("paho").setLevel(logging.WARNING)

# --- Connection mode ---
# Priority: MOXA_IP set → TCP, else SERIAL_PORT/default → serial
MOXA_IP      = os.getenv("MOXA_IP", "")
MOXA_PORT    = int(os.getenv("MOXA_PORT", "4001"))
SERIAL_PORT  = os.getenv("SERIAL_PORT", "/dev/ttyUSB0")
SERIAL_BAUD  = int(os.getenv("SERIAL_BAUD", "2400"))

USE_MOXA = bool(MOXA_IP)

# --- MQTT ---
MQTT_BROKER    = os.getenv("MQTT_BROKER", "192.168.8.204")
MQTT_PORT      = int(os.getenv("MQTT_PORT", "1883"))
MQTT_BASE      = os.getenv("MQTT_BASE_TOPIC", "inverter")
MQTT_USER      = os.getenv("MQTT_USER", "easun")
MQTT_PASS      = os.getenv("MQTT_PASS", "easun123")
DISCOVERY_PREFIX = os.getenv("DISCOVERY_PREFIX", "homeassistant")
DEVICE_ID      = os.getenv("DEVICE_ID", "easun_inverter")

# --- Poll intervals ---
POLL_LIVE      = int(os.getenv("POLL_LIVE",     "10"))
POLL_SETTINGS  = int(os.getenv("POLL_SETTINGS", "60"))
POLL_ENERGY    = int(os.getenv("POLL_ENERGY",   "60"))
POLL_FAULTS    = int(os.getenv("POLL_FAULTS",   "30"))

# --- Mode mapping ---
MODE_MAP = {
    0: "Battery",   # confirmed: inverter running on battery overnight (no grid/PV)
    1: "Standby",
    2: "Utility",   # confirmed: grid + solar daytime
    3: "Battery",
    4: "PV",
    5: "Hybrid",
    6: "Bypass",
    7: "Fault",
}

CHARGE_PRIORITY_MAP = {
    0: "Solar First",
    1: "Solar and Utility",
    2: "Solar Only",
}

# --- Device info for discovery ---
DEVICE_INFO = {
    "identifiers": [DEVICE_ID],
    "name": "EASUN Inverter",
    "model": "EASUN Hybrid",
    "manufacturer": "EASUN",
}

# --- Sensor definitions for discovery ---
# (unique_id_suffix, name, subtopic, unit, device_class, state_class, icon, entity_category)
SENSORS = [
    # Live data
    ("output_voltage_v",        "Output Voltage",           "live/output_voltage_v",        "V",    "voltage",      "measurement",  None,                       None),
    ("output_freq_hz",          "Output Frequency",         "live/output_freq_hz",          "Hz",   "frequency",    "measurement",  None,                       None),
    ("active_power_w",          "Active Power",             "live/active_power_w",          "W",    "power",        "measurement",  None,                       None),
    ("apparent_power_va",       "Apparent Power",           "live/apparent_power_va",       "VA",   None,           "measurement",  "mdi:flash",                None),
    ("load_percent",            "Load Percent",             "live/load_percent",            "%",    None,           "measurement",  "mdi:gauge",                None),
    ("grid_freq_hz",            "Grid Frequency",           "live/grid_freq_hz",            "Hz",   "frequency",    "measurement",  None,                       None),
    ("battery_voltage_v",       "Battery Voltage",          "live/battery_voltage_v",       "V",    "voltage",      "measurement",  None,                       None),
    ("battery_soc_percent",     "Battery SOC",              "live/battery_soc_percent",     "%",    "battery",      "measurement",  None,                       None),
    ("battery_power_w",         "Battery Power",            "live/battery_power_w",         "W",    "power",        "measurement",  "mdi:battery-charging",     None),
    ("battery_charge_power_w",  "Battery Charge Power",     "live/battery_charge_power_w",  "W",    "power",        "measurement",  "mdi:battery-plus",         None),
    ("battery_discharge_power_w","Battery Discharge Power", "live/battery_discharge_power_w","W",   "power",        "measurement",  "mdi:battery-minus",        None),
    ("batt_charge_current_a",   "Battery Charge Current",   "live/batt_charge_current_a",   "A",    "current",      "measurement",  None,                       None),
    ("batt_discharge_current_a","Battery Discharge Current","live/batt_discharge_current_a","A",    "current",      "measurement",  None,                       None),
    ("inverter_temp_c",         "Inverter Temperature",     "live/inverter_temp_c",         "°C",   "temperature",  "measurement",  None,                       None),
    ("pv1_power_w",             "PV1 Power",                "live/pv1_power_w",             "W",    "power",        "measurement",  "mdi:solar-power",          None),
    ("pv2_power_w",             "PV2 Power",                "live/pv2_power_w",             "W",    "power",        "measurement",  "mdi:solar-power",          None),
    ("pv1_voltage_v",           "PV1 Voltage",              "live/pv1_voltage_v",           "V",    "voltage",      "measurement",  None,                       None),
    ("pv2_voltage_v",           "PV2 Voltage",              "live/pv2_voltage_v",           "V",    "voltage",      "measurement",  None,                       None),
    ("mode",                    "Inverter Mode",            "live/mode",                    None,   "enum",         None,           "mdi:solar-power-variant",  None),
    ("grid_ok",                 "Grid OK",                  "live/grid_ok",                 None,   None,           None,           "mdi:transmission-tower",   None),
    ("alarm",                   "Alarm",                    "live/alarm",                   None,   None,           None,           "mdi:alert",                None),
    # Settings
    ("battery_recharge_voltage_v",   "Battery Recharge Voltage",      "settings/battery_recharge_voltage_v",   "V",  "voltage", "measurement",  None,                            "config"),
    ("battery_redischarge_voltage_v","Battery Redischarge Voltage",   "settings/battery_redischarge_voltage_v","V",  "voltage", "measurement",  None,                            "config"),
    ("battery_bulk_voltage_v",       "Battery Bulk Voltage",          "settings/battery_bulk_voltage_v",       "V",  "voltage", "measurement",  None,                            "config"),
    ("battery_float_voltage_v",      "Battery Float Voltage",         "settings/battery_float_voltage_v",      "V",  "voltage", "measurement",  None,                            "config"),
    ("battery_cutoff_voltage_v",     "Battery Cutoff Voltage",        "settings/battery_cutoff_voltage_v",     "V",  "voltage", "measurement",  None,                            "config"),
    # Energy
    ("energy_today_kwh",        "Energy Today",             "energy/energy_today_kwh",      "kWh",  "energy",       "total_increasing", "mdi:solar-power",          None),
    ("energy_total_kwh",        "Energy Total",             "energy/energy_total_kwh",      "kWh",  "energy",       "total_increasing", "mdi:solar-power",          None),
    # Faults → entity_category=diagnostic → shows in Diagnostic card
    ("fault_active",            "Fault Active",             "faults/fault_active",          None,   None,           None,           "mdi:alert-circle",             "diagnostic"),
    ("fault_raw",               "Fault Raw",                "faults/fault_raw",             None,   None,           None,           "mdi:alert-circle-outline",     "diagnostic"),
]

# --- CRC ---
def crc16_xmodem(data: bytes) -> bytes:
    crc = 0
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = (crc << 1) ^ 0x1021 if crc & 0x8000 else crc << 1
        crc &= 0xFFFF
    return bytes([(crc >> 8) & 0xFF, crc & 0xFF])

def make_cmd(payload_str: str) -> bytes:
    payload = payload_str.encode('ascii')
    crc = crc16_xmodem(b'\x5e' + payload)
    return b'\x5e' + payload + crc + b'\x0d'

# --- Connection ---
ser = None
sock = None

def open_connection():
    global ser, sock
    while True:
        try:
            if USE_MOXA:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((MOXA_IP, MOXA_PORT))
                logging.info(f"TCP connected to {MOXA_IP}:{MOXA_PORT}")
            else:
                ser = serial.Serial(SERIAL_PORT, SERIAL_BAUD, timeout=5)
                logging.info(f"Serial {SERIAL_PORT} opened at {SERIAL_BAUD} baud")
            return
        except Exception as e:
            logging.error(f"Connection failed: {e}, retrying in 5s")
            time.sleep(5)

def query(cmd_str: str) -> str:
    global ser, sock
    cmd = make_cmd(cmd_str)
    logging.debug(f"TX: {cmd.hex()} ({cmd_str!r})")
    try:
        if USE_MOXA:
            # Drain any stale data before sending
            sock.setblocking(False)
            try:
                while sock.recv(256):
                    pass
            except BlockingIOError:
                pass
            sock.setblocking(True)
            sock.settimeout(5)
            time.sleep(0.05)
            sock.sendall(cmd)
            response = b""
            deadline = time.time() + 5.0
            while time.time() < deadline:
                try:
                    byte = sock.recv(1)
                    if byte:
                        response += byte
                        if byte == b"\x0d":
                            break
                except socket.timeout:
                    break
        else:
            # Flush any stale data in buffer before sending
            ser.reset_input_buffer()
            time.sleep(0.05)  # brief settle at 2400 baud
            ser.reset_input_buffer()
            ser.write(cmd)
            ser.flush()
            response = b""
            deadline = time.time() + 5.0
            while time.time() < deadline:
                byte = ser.read(1)
                if byte:
                    response += byte
                    if byte == b"\x0d":
                        break
    except (serial.SerialException, OSError) as e:
        logging.error(f"Connection error: {e}, reconnecting...")
        open_connection()
        return ""

    if not response:
        logging.warning(f"No response to {cmd_str}")
        return ""

    logging.debug(f"RX: {response.hex()} ({response.decode('ascii', errors='replace').strip()!r})")

    try:
        txt = response.decode('ascii', errors='ignore').strip()
    except Exception:
        return ""

    if txt.startswith("^D") and len(txt) >= 5:
        txt = txt[5:]

    # Small inter-command gap — gives inverter time to settle
    time.sleep(0.1)

    return txt

# --- Parsers ---
def parse_gs(raw: str) -> dict:
    fields = raw.split(",")
    if len(fields) < 24:
        logging.warning(f"GS: unexpected field count {len(fields)}")
        return {}
    parsed = {}
    try:
        parsed["grid_freq_hz"]              = round(int(fields[1]) / 10, 1)
        parsed["output_voltage_v"]          = round(int(fields[2]) / 10, 1)
        parsed["output_freq_hz"]            = round(int(fields[3]) / 10, 1)
        parsed["apparent_power_va"]         = int(fields[4])
        parsed["active_power_w"]            = int(fields[5])
        parsed["load_percent"]              = int(fields[6])
        parsed["battery_voltage_v"]         = round(int(fields[7]) / 10, 1)
        parsed["batt_charge_current_a"]     = int(fields[11])
        parsed["battery_soc_percent"]       = int(fields[12])
        parsed["inverter_temp_c"]           = int(fields[13])
        parsed["batt_discharge_current_a"]  = int(fields[14])
        parsed["pv1_power_w"]               = int(fields[16])
        parsed["pv2_power_w"]               = int(fields[17])
        parsed["pv1_voltage_v"]             = round(int(fields[18]) / 10, 1)
        parsed["pv2_voltage_v"]             = round(int(fields[19]) / 10, 1)
    except Exception as e:
        logging.warning(f"GS parse error: {e}")

    try:
        vbat        = parsed.get("battery_voltage_v", 0)
        charge_a    = parsed.get("batt_charge_current_a", 0)
        discharge_a = parsed.get("batt_discharge_current_a", 0)
        if charge_a > 0:
            parsed["battery_power_w"] = round(vbat * charge_a, 1)
        elif discharge_a > 0:
            parsed["battery_power_w"] = round(-vbat * discharge_a, 1)
        else:
            parsed["battery_power_w"] = 0
        parsed["battery_charge_power_w"]    = round(vbat * charge_a, 1) if charge_a > 0 else 0
        parsed["battery_discharge_power_w"] = round(vbat * discharge_a, 1) if discharge_a > 0 else 0
    except Exception as e:
        logging.warning(f"GS battery calc error: {e}")

    try:
        parsed["grid_ok"] = (fields[20] == "0")
        parsed["mode"]    = MODE_MAP.get(int(fields[21]), f"Unknown({fields[21]})")
        parsed["alarm"]   = (fields[22] != "0")
    except Exception as e:
        logging.warning(f"GS flags error: {e}")

    return parsed

def parse_piri(raw: str) -> dict:
    fields = raw.split(",")
    if len(fields) < 19:
        logging.warning(f"PIRI: unexpected field count {len(fields)}")
        return {}
    parsed = {}
    try:
        parsed["output_voltage_setting_v"]      = round(int(fields[2]) / 10, 1)
        parsed["output_freq_setting_hz"]        = round(int(fields[3]) / 10, 1)
        parsed["battery_bulk_voltage_v"]        = round(int(fields[11]) / 10, 1)  # 56.4V
        parsed["battery_float_voltage_v"]       = round(int(fields[12]) / 10, 1)  # 54.0V
        parsed["battery_cutoff_voltage_v"]      = round(int(fields[10]) / 10, 1)  # 45.0V
        parsed["battery_recharge_voltage_v"]    = round(int(fields[8]) / 10, 1)   # field[8] = recharge
        parsed["battery_redischarge_voltage_v"] = round(int(fields[9]) / 10, 1)   # field[9] = redischarge (0=Full)
        parsed["max_ac_charging_current_a"]     = int(fields[14])
        parsed["max_total_charging_current_a"]  = int(fields[15])
        parsed["charge_source_priority"]        = CHARGE_PRIORITY_MAP.get(int(fields[18]), f"Unknown({fields[18]})")
        parsed["charge_source_priority_id"]     = int(fields[18])
        # Update select entity states
        priority_label = CHARGE_PRIORITY_MAP.get(int(fields[18]))
        if priority_label:
            mqtt_client.publish(CHARGE_PRIORITY_SELECT_TOPIC, priority_label, qos=0, retain=True)
            select_state["charge_priority"] = priority_label
        select_state["ac_current"] = str(int(fields[14]))
        mqtt_client.publish(AC_CURRENT_SELECT_TOPIC, str(int(fields[14])), qos=0, retain=True)
        # Sync voltage_state and publish voltage selects
        recharge_v    = round(int(fields[8]) / 10)
        redischarge_v = round(int(fields[9]) / 10)  # 0 = Full
        voltage_state["recharge"]    = recharge_v
        voltage_state["redischarge"] = redischarge_v
        mqtt_client.publish(RECHARGE_SELECT_TOPIC,    str(recharge_v),                          qos=0, retain=True)
        mqtt_client.publish(REDISCHARGE_SELECT_TOPIC, "Full" if redischarge_v == 0 else str(redischarge_v), qos=0, retain=True)
        # Sync POP and PSP selects
        if len(fields) > 17:
            pop_label = POP_MAP.get(int(fields[17]))
            if pop_label:
                parsed["output_source_priority"] = pop_label
                mqtt_client.publish(POP_SELECT_TOPIC, pop_label, qos=0, retain=True)
                select_state["pop"] = pop_label
        if len(fields) > 23:
            psp_label = PSP_MAP.get(int(fields[23]))
            if psp_label:
                parsed["solar_power_priority"] = psp_label
                mqtt_client.publish(PSP_SELECT_TOPIC, psp_label, qos=0, retain=True)
                select_state["psp"] = psp_label
    except Exception as e:
        logging.warning(f"PIRI parse error: {e}")
    return parsed

def parse_acct(raw: str) -> dict:
    parts = raw.strip().split(",")
    if len(parts) != 2:
        return {}
    # Convert HHMM to HH:MM for HA time entity
    def hhmm_to_time(hhmm: str) -> str:
        hhmm = ''.join(c for c in hhmm if c.isdigit())[:4].zfill(4)
        return f"{hhmm[:2]}:{hhmm[2:]}"
    start_time = hhmm_to_time(parts[0])
    end_time   = hhmm_to_time(parts[1])
    acct_state["start"] = start_time
    acct_state["end"]   = end_time
    mqtt_client.publish(ACCT_START_TOPIC, start_time, qos=0, retain=True)
    mqtt_client.publish(ACCT_END_TOPIC,   end_time,   qos=0, retain=True)
    return {
        "ac_charge_start":  start_time,
        "ac_charge_end":    end_time,
        "ac_charge_active": parts[0] != "0000" or parts[1] != "0000",
    }

def parse_vfw(raw: str) -> dict:
    parts = raw.strip().split(",")
    parsed = {}
    try:
        parsed["energy_today_kwh"] = round(int(parts[0]) / 100, 2)
        parsed["energy_total_kwh"] = round(int(parts[1]) / 100, 2)
    except Exception as e:
        logging.warning(f"VFW parse error: {e}")
    return parsed

def parse_fws(raw: str) -> dict:
    fields = raw.split(",")
    parsed = {}
    try:
        # field[9]=1 is normal/expected, not a fault - exclude it
        fault_fields = [f.strip().rstrip("|") for i, f in enumerate(fields) if i != 9]
        parsed["fault_active"] = any(f not in ("0", "00", "") for f in fault_fields)
        parsed["fault_raw"]    = raw.strip().rstrip("|")
    except Exception as e:
        logging.warning(f"FWS parse error: {e}")
    return parsed

# --- MQTT ---
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        logging.info("MQTT connected")
        cleanup_old_discovery()
        publish_discovery()
        publish_select_discovery()
        mqtt_client.subscribe(CHARGE_PRIORITY_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(AC_CURRENT_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(RECHARGE_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(REDISCHARGE_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(POP_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(PSP_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(ACCT_START_CMD_TOPIC, qos=1)
        mqtt_client.subscribe(ACCT_END_CMD_TOPIC, qos=1)
        logging.info(f"Subscribed to command topics")
    else:
        logging.warning(f"MQTT connect failed rc={rc}")

def on_disconnect(client, userdata, rc):
    if rc != 0:
        logging.warning(f"MQTT disconnected rc={rc}")

mqtt_client = mqtt.Client(protocol=mqtt.MQTTv311)
mqtt_client.username_pw_set(MQTT_USER, MQTT_PASS)
mqtt_client.on_connect = on_connect
mqtt_client.on_disconnect = on_disconnect
mqtt_client.reconnect_delay_set(min_delay=1, max_delay=30)

CHARGE_PRIORITY_OPTIONS = ["Solar First", "Solar and Utility", "Solar Only"]
CHARGE_PRIORITY_CMD = {
    "Solar First":        "S009PCP0,0",
    "Solar and Utility":  "S009PCP0,1",
    "Solar Only":         "S009PCP0,2",
}
CHARGE_PRIORITY_SELECT_TOPIC = "inverter/select/charge_source_priority/state"
CHARGE_PRIORITY_CMD_TOPIC    = "inverter/select/charge_source_priority/set"

AC_CURRENT_OPTIONS = ["2", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120"]
AC_CURRENT_SELECT_TOPIC = "inverter/select/max_ac_charging_current/state"
AC_CURRENT_CMD_TOPIC    = "inverter/select/max_ac_charging_current/set"

RECHARGE_OPTIONS = ["44", "45", "46", "47", "48", "49", "50", "51"]
RECHARGE_SELECT_TOPIC = "inverter/select/battery_recharge_voltage/state"
RECHARGE_CMD_TOPIC    = "inverter/select/battery_recharge_voltage/set"

REDISCHARGE_OPTIONS = ["Full", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58"]
REDISCHARGE_SELECT_TOPIC = "inverter/select/battery_redischarge_voltage/state"
REDISCHARGE_CMD_TOPIC    = "inverter/select/battery_redischarge_voltage/set"

# Output Source Priority (POP) - field[17] in PIRI
POP_MAP = {
    0: "Solar-Utility-Battery",
    1: "Solar-Battery-Utility",
}
POP_CMD = {
    "Solar-Utility-Battery": "S007POP0",
    "Solar-Battery-Utility": "S007POP1",
}
POP_OPTIONS = ["Solar-Utility-Battery", "Solar-Battery-Utility"]
POP_SELECT_TOPIC = "inverter/select/output_source_priority/state"
POP_CMD_TOPIC    = "inverter/select/output_source_priority/set"

# Solar Power Priority (PSP) - field[23] in PIRI
PSP_MAP = {
    0: "Battery-Load-Utility",
    1: "Load-Battery-Utility",
    2: "Load-Utility-Battery",
}
PSP_CMD = {
    "Battery-Load-Utility": "S007PSP0",
    "Load-Battery-Utility": "S007PSP1",
    "Load-Utility-Battery": "S007PSP2",
}
PSP_OPTIONS = ["Battery-Load-Utility", "Load-Battery-Utility", "Load-Utility-Battery"]
PSP_SELECT_TOPIC = "inverter/select/solar_power_priority/state"
PSP_CMD_TOPIC    = "inverter/select/solar_power_priority/set"

# AC Charging Duration (ACCT) - time inputs
ACCT_START_TOPIC     = "inverter/time/ac_charge_start/state"
ACCT_END_TOPIC       = "inverter/time/ac_charge_end/state"
ACCT_START_CMD_TOPIC = "inverter/time/ac_charge_start/set"
ACCT_END_CMD_TOPIC   = "inverter/time/ac_charge_end/set"

# Current known select states (for restoring HA on NAK)
select_state = {
    "charge_priority": "Solar Only",
    "ac_current": "2",
    "pop": "Solar-Battery-Utility",
    "psp": "Load-Battery-Utility",
}

# Current known ACCT state (needed to send both together)
acct_state = {
    "start": "00:00",
    "end":   "00:00",
}

# Current known voltage state (needed to send both together in BUCD command)
voltage_state = {
    "recharge":    46,   # default, updated from PIRI
    "redischarge": 48,   # default, updated from PIRI
}

def publish_select_discovery():
    """Publish MQTT discovery for select entities."""
    # Charge source priority
    unique_id = f"{DEVICE_ID}_charge_source_priority"
    payload = {
        "name": "Charge Source Priority",
        "unique_id": unique_id,
        "state_topic": CHARGE_PRIORITY_SELECT_TOPIC,
        "command_topic": CHARGE_PRIORITY_CMD_TOPIC,
        "options": CHARGE_PRIORITY_OPTIONS,
        "icon": "mdi:battery-charging-settings",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{unique_id}/config", json.dumps(payload), qos=1, retain=True)

    # Max AC charging current
    unique_id2 = f"{DEVICE_ID}_max_ac_charging_current"
    payload2 = {
        "name": "Max AC Charging Current",
        "unique_id": unique_id2,
        "state_topic": AC_CURRENT_SELECT_TOPIC,
        "command_topic": AC_CURRENT_CMD_TOPIC,
        "options": AC_CURRENT_OPTIONS,
        "icon": "mdi:current-ac",
        "unit_of_measurement": "A",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{unique_id2}/config", json.dumps(payload2), qos=1, retain=True)

    # Battery recharge voltage
    uid3 = f"{DEVICE_ID}_battery_recharge_voltage"
    payload3 = {
        "name": "Battery Recharge Voltage",
        "unique_id": uid3,
        "state_topic": RECHARGE_SELECT_TOPIC,
        "command_topic": RECHARGE_CMD_TOPIC,
        "options": RECHARGE_OPTIONS,
        "icon": "mdi:battery-arrow-up",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{uid3}/config", json.dumps(payload3), qos=1, retain=True)

    # Battery redischarge voltage
    uid4 = f"{DEVICE_ID}_battery_redischarge_voltage"
    payload4 = {
        "name": "Battery Redischarge Voltage",
        "unique_id": uid4,
        "state_topic": REDISCHARGE_SELECT_TOPIC,
        "command_topic": REDISCHARGE_CMD_TOPIC,
        "options": REDISCHARGE_OPTIONS,
        "icon": "mdi:battery-arrow-down",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{uid4}/config", json.dumps(payload4), qos=1, retain=True)

    # Output Source Priority
    uid5 = f"{DEVICE_ID}_output_source_priority"
    payload5 = {
        "name": "Output Source Priority",
        "unique_id": uid5,
        "state_topic": POP_SELECT_TOPIC,
        "command_topic": POP_CMD_TOPIC,
        "options": POP_OPTIONS,
        "icon": "mdi:power-plug",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{uid5}/config", json.dumps(payload5), qos=1, retain=True)

    # Solar Power Priority
    uid6 = f"{DEVICE_ID}_solar_power_priority"
    payload6 = {
        "name": "Solar Power Priority",
        "unique_id": uid6,
        "state_topic": PSP_SELECT_TOPIC,
        "command_topic": PSP_CMD_TOPIC,
        "options": PSP_OPTIONS,
        "icon": "mdi:solar-power",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/select/{uid6}/config", json.dumps(payload6), qos=1, retain=True)

    # AC Charge Start time
    uid_acct_start = f"{DEVICE_ID}_ac_charge_start_time"
    payload_acct_start = {
        "name": "AC Charge Start",
        "unique_id": uid_acct_start,
        "state_topic": ACCT_START_TOPIC,
        "command_topic": ACCT_START_CMD_TOPIC,
        "pattern": "^([01]\\d|2[0-3]):[0-5]\\d$",
        "icon": "mdi:clock-start",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/text/{uid_acct_start}/config", json.dumps(payload_acct_start), qos=1, retain=True)

    # AC Charge End text
    uid_acct_end = f"{DEVICE_ID}_ac_charge_end_time"
    payload_acct_end = {
        "name": "AC Charge End",
        "unique_id": uid_acct_end,
        "state_topic": ACCT_END_TOPIC,
        "command_topic": ACCT_END_CMD_TOPIC,
        "pattern": "^([01]\\d|2[0-3]):[0-5]\\d$",
        "icon": "mdi:clock-end",
        "device": DEVICE_INFO,
    }
    mqtt_client.publish(f"{DISCOVERY_PREFIX}/text/{uid_acct_end}/config", json.dumps(payload_acct_end), qos=1, retain=True)

    logging.info("Published select discovery for all controls")

def on_message(client, userdata, msg):
    """Handle incoming MQTT commands."""
    if msg.topic == CHARGE_PRIORITY_CMD_TOPIC:
        value = msg.payload.decode().strip()
        logging.info(f"Charge priority command received: {value}")
        if value not in CHARGE_PRIORITY_CMD:
            logging.warning(f"Unknown charge priority: {value}")
            return
        cmd = CHARGE_PRIORITY_CMD[value]
        try:
            raw = query(cmd)
            if raw.startswith("^1") or "1" in raw:
                logging.info(f"Charge priority set to {value} ✅")
                select_state["charge_priority"] = value
                mqtt_client.publish(CHARGE_PRIORITY_SELECT_TOPIC, value, qos=0, retain=True)
            else:
                logging.warning(f"Charge priority set failed, response: {raw}")
                mqtt_client.publish(CHARGE_PRIORITY_SELECT_TOPIC, select_state["charge_priority"], qos=0, retain=True)
        except Exception as e:
            logging.error(f"Charge priority command error: {e}")

    elif msg.topic == AC_CURRENT_CMD_TOPIC:
        value = msg.payload.decode().strip()
        logging.info(f"Max AC current command received: {value}A")
        if value not in AC_CURRENT_OPTIONS:
            logging.warning(f"Unknown AC current value: {value}")
            return
        cmd = f"S014MUCHGC0,{int(value):03d}"
        try:
            raw = query(cmd)
            if raw.startswith("^1") or "1" in raw:
                logging.info(f"Max AC current set to {value}A ✅")
                select_state["ac_current"] = value
                mqtt_client.publish(AC_CURRENT_SELECT_TOPIC, value, qos=0, retain=True)
            else:
                logging.warning(f"Max AC current set failed, response: {raw}")
                mqtt_client.publish(AC_CURRENT_SELECT_TOPIC, select_state["ac_current"], qos=0, retain=True)
        except Exception as e:
            logging.error(f"Max AC current command error: {e}")

    elif msg.topic in (RECHARGE_CMD_TOPIC, REDISCHARGE_CMD_TOPIC):
        value = msg.payload.decode().strip()
        is_recharge = msg.topic == RECHARGE_CMD_TOPIC
        label = "Recharge" if is_recharge else "Redischarge"
        logging.info(f"Battery {label} voltage command received: {value}V")

        if is_recharge:
            if value not in RECHARGE_OPTIONS:
                logging.warning(f"Unknown recharge voltage: {value}")
                return
            pending_recharge = int(value)
            pending_redischarge = voltage_state["redischarge"]
        else:
            if value not in REDISCHARGE_OPTIONS:
                logging.warning(f"Unknown redischarge voltage: {value}")
                return
            pending_recharge = voltage_state["recharge"]
            pending_redischarge = 0 if value == "Full" else int(value)

        recharge_val    = pending_recharge * 10
        redischarge_val = pending_redischarge * 10
        cmd = f"S014BUCD{recharge_val:03d},{redischarge_val:03d}"
        try:
            raw = query(cmd)
            if raw.startswith("^1") or "1" in raw:
                voltage_state["recharge"]    = pending_recharge
                voltage_state["redischarge"] = pending_redischarge
                logging.info(f"Battery voltages set: recharge={pending_recharge}V redischarge={value}V ✅")
                if is_recharge:
                    mqtt_client.publish(RECHARGE_SELECT_TOPIC, value, qos=0, retain=True)
                else:
                    mqtt_client.publish(REDISCHARGE_SELECT_TOPIC, value, qos=0, retain=True)
            else:
                logging.warning(f"Battery voltage set failed, response: {raw}")
                mqtt_client.publish(RECHARGE_SELECT_TOPIC, str(voltage_state["recharge"]), qos=0, retain=True)
                mqtt_client.publish(REDISCHARGE_SELECT_TOPIC,
                    "Full" if voltage_state["redischarge"] == 0 else str(voltage_state["redischarge"]),
                    qos=0, retain=True)
        except Exception as e:
            logging.error(f"Battery voltage command error: {e}")

    elif msg.topic == POP_CMD_TOPIC:
        value = msg.payload.decode().strip()
        logging.info(f"Output source priority command received: {value}")
        if value not in POP_CMD:
            logging.warning(f"Unknown output source priority: {value}")
            return
        try:
            raw = query(POP_CMD[value])
            if raw.startswith("^1") or "1" in raw:
                logging.info(f"Output source priority set to {value} ✅")
                select_state["pop"] = value
                mqtt_client.publish(POP_SELECT_TOPIC, value, qos=0, retain=True)
            else:
                logging.warning(f"Output source priority set failed, response: {raw}")
                mqtt_client.publish(POP_SELECT_TOPIC, select_state["pop"], qos=0, retain=True)
        except Exception as e:
            logging.error(f"Output source priority command error: {e}")

    elif msg.topic == PSP_CMD_TOPIC:
        value = msg.payload.decode().strip()
        logging.info(f"Solar power priority command received: {value}")
        if value not in PSP_CMD:
            logging.warning(f"Unknown solar power priority: {value}")
            return
        try:
            raw = query(PSP_CMD[value])
            if raw.startswith("^1") or "1" in raw:
                logging.info(f"Solar power priority set to {value} ✅")
                select_state["psp"] = value
                mqtt_client.publish(PSP_SELECT_TOPIC, value, qos=0, retain=True)
            else:
                logging.warning(f"Solar power priority set failed, response: {raw}")
                mqtt_client.publish(PSP_SELECT_TOPIC, select_state["psp"], qos=0, retain=True)
        except Exception as e:
            logging.error(f"Solar power priority command error: {e}")

    elif msg.topic in (ACCT_START_CMD_TOPIC, ACCT_END_CMD_TOPIC):
        value = msg.payload.decode().strip()  # HH:MM from HA
        is_start = msg.topic == ACCT_START_CMD_TOPIC
        label = "start" if is_start else "end"
        logging.info(f"AC charge {label} time command received: {value}")
        # Validate HH:MM format
        try:
            h, m = value.split(":")
            assert 0 <= int(h) <= 23 and 0 <= int(m) <= 59
        except Exception:
            logging.warning(f"Invalid time format: {value}")
            return
        # Build HHMM strings using pending value, but don't update state yet
        prev_value = acct_state[label]
        start_hhmm = (value if is_start else acct_state["start"])[:5].replace(":", "")
        end_hhmm   = (value if not is_start else acct_state["end"])[:5].replace(":", "")
        cmd = f"S016ACCT{start_hhmm},{end_hhmm}"
        try:
            raw = query(cmd)
            if raw.startswith("^1") or "1" in raw:
                # Only update state on confirmed ACK
                acct_state[label] = value
                logging.info(f"AC charge time set: {acct_state['start']}~{acct_state['end']} ✅")
                mqtt_client.publish(ACCT_START_TOPIC, acct_state["start"], qos=0, retain=True)
                mqtt_client.publish(ACCT_END_TOPIC,   acct_state["end"],   qos=0, retain=True)
            else:
                logging.warning(f"AC charge time set failed, response: {raw}")
                # Restore HA to current inverter state
                mqtt_client.publish(ACCT_START_TOPIC, acct_state["start"], qos=0, retain=True)
                mqtt_client.publish(ACCT_END_TOPIC,   acct_state["end"],   qos=0, retain=True)
        except Exception as e:
            logging.error(f"AC charge time command error: {e}")

mqtt_client.on_message = on_message


def cleanup_old_discovery():
    old_ids = [
        "grid_voltage_v", "pv_power_w", "mode", "battery_soc",
        "batt_charge_current", "batt_discharge_current", "load_percent",
        "grid_freq", "battery_voltage", "battery_power", "battery_charge_power",
        "battery_discharge_power", "charge_source_priority", "max_ac_charging_current_a",
    ]
    for uid in old_ids:
        topic = f"{DISCOVERY_PREFIX}/sensor/{DEVICE_ID}_{uid}/config"
        mqtt_client.publish(topic, "", qos=1, retain=True)  # empty payload = delete
    logging.info(f"Cleaned up {len(old_ids)} old discovery topics")

def publish_discovery():
    """Publish MQTT discovery messages for all sensors."""
    logging.info("Publishing MQTT discovery messages...")
    for uid, name, subtopic, unit, device_class, state_class, icon, entity_category in SENSORS:
        unique_id = f"{DEVICE_ID}_{uid}"
        state_topic = f"{MQTT_BASE}/{subtopic}"
        payload = {
            "name": name,
            "unique_id": unique_id,
            "state_topic": state_topic,
            "device": DEVICE_INFO,
        }
        if unit:
            payload["unit_of_measurement"] = unit
        if device_class and device_class != "enum":
            payload["device_class"] = device_class
        if state_class:
            payload["state_class"] = state_class
        if icon:
            payload["icon"] = icon
        if entity_category:
            payload["entity_category"] = entity_category

        discovery_topic = f"{DISCOVERY_PREFIX}/sensor/{unique_id}/config"
        mqtt_client.publish(discovery_topic, json.dumps(payload), qos=1, retain=True)

    logging.info(f"Published {len(SENSORS)} discovery messages")

def mqtt_connect():
    while True:
        try:
            mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
            mqtt_client.loop_start()
            return
        except Exception as e:
            logging.error(f"MQTT connect failed: {e}, retrying in 5s")
            time.sleep(5)

def publish(subtopic: str, value):
    mqtt_client.publish(f"{MQTT_BASE}/{subtopic}", str(value), qos=0, retain=True)

def publish_dict(prefix: str, data: dict):
    timestamp = datetime.now(timezone.utc).isoformat()
    for k, v in data.items():
        publish(f"{prefix}/{k}", v)
    publish(f"{prefix}/last_update", timestamp)

# --- Main loop ---
def main():
    if USE_MOXA:
        logging.info(f"Connection mode: TCP (Moxa) {MOXA_IP}:{MOXA_PORT}")
    else:
        logging.info(f"Connection mode: Serial {SERIAL_PORT} @ {SERIAL_BAUD} baud")
    open_connection()
    mqtt_connect()

    # Wait for MQTT connection and discovery to be published
    timeout = time.time() + 10
    while not mqtt_client.is_connected() and time.time() < timeout:
        time.sleep(0.1)
    time.sleep(1)  # give HA time to process discovery messages

    last_settings = 0
    last_energy   = 0
    last_faults   = 0

    logging.info("Poller started")

    while True:
        now = time.time()

        try:
            raw = query("P005GS")
            if raw:
                parsed = parse_gs(raw)
                if parsed:
                    publish_dict("live", parsed)
                    logging.info(f"GS: {parsed.get('active_power_w')}W bat={parsed.get('battery_voltage_v')}V soc={parsed.get('battery_soc_percent')}% pv={parsed.get('pv1_power_w')}W mode={parsed.get('mode')}")
        except Exception as e:
            logging.error(f"GS poll error: {e}")

        if now - last_settings >= POLL_SETTINGS:
            try:
                raw = query("P007PIRI")
                if raw:
                    parsed = parse_piri(raw)
                    if parsed:
                        publish_dict("settings", parsed)
                        logging.info(f"PIRI: charge={parsed.get('charge_source_priority')} max_ac={parsed.get('max_ac_charging_current_a')}A")
            except Exception as e:
                logging.error(f"PIRI poll error: {e}")

            try:
                raw = query("P007ACCT")
                if raw:
                    parsed = parse_acct(raw)
                    if parsed:
                        publish_dict("settings", parsed)
                        logging.info(f"ACCT: {parsed.get('ac_charge_start')}~{parsed.get('ac_charge_end')} active={parsed.get('ac_charge_active')}")
            except Exception as e:
                logging.error(f"ACCT poll error: {e}")

            last_settings = now

        if now - last_energy >= POLL_ENERGY:
            try:
                raw = query("P006VFW")
                if raw:
                    parsed = parse_vfw(raw)
                    if parsed:
                        publish_dict("energy", parsed)
                        logging.info(f"VFW: today={parsed.get('energy_today_kwh')}kWh total={parsed.get('energy_total_kwh')}kWh")
            except Exception as e:
                logging.error(f"VFW poll error: {e}")

            last_energy = now

        if now - last_faults >= POLL_FAULTS:
            try:
                raw = query("P006FWS")
                if raw:
                    parsed = parse_fws(raw)
                    if parsed:
                        publish_dict("faults", parsed)
                        if parsed.get("fault_active"):
                            logging.warning(f"FAULT: {parsed.get('fault_raw')}")
            except Exception as e:
                logging.error(f"FWS poll error: {e}")

            last_faults = now

        time.sleep(POLL_LIVE)

if __name__ == "__main__":
    main()
