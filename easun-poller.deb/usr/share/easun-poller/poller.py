#!/usr/bin/env python3
import os
import socket
import time
import json
import paho.mqtt.client as mqtt
from datetime import datetime, timezone

# --- Inverter connection ---
MOXA_IP = os.getenv("MOXA_IP", "192.168.8.201")
MOXA_PORT = int(os.getenv("MOXA_PORT", "4001"))
command = b"^P005GSX.\r"

# --- MQTT connection ---
MQTT_BROKER = os.getenv("MQTT_BROKER", "192.168.8.204")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_BASE_TOPIC = os.getenv("MQTT_BASE_TOPIC", "inverter")
MQTT_USER = os.getenv("MQTT_USER", "easun")
MQTT_PASS = os.getenv("MQTT_PASS", "easun123")

POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "10"))  # seconds between polls

# --- Mode mapping table ---
MODE_MAP = {
    0: "Power Off / Init",
    1: "Standby",
    2: "Utility",
    3: "Battery",
    4: "PV",
    5: "Hybrid",
    6: "Bypass",
    7: "Fault",
}

EXPORT_POLICY_MAP = {
    0: "Hybrid (normal, feed-in allowed)",
    8: "Off-grid (no feed-in)",
}

# --- Poll inverter ---
def poll_inverter():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(5)
        s.connect((MOXA_IP, MOXA_PORT))
        s.sendall(command)
        data = b""
        while True:
            chunk = s.recv(1024)
            if not chunk:
                break
            data += chunk
            if data.endswith(b"\r") or data.endswith(b"\n"):
                break
    reply = data.decode(errors="ignore").strip()
    if reply.startswith("^D") and len(reply) >= 5:
        reply = reply[5:]
    return reply

# --- Parse reply fields ---
def parse_fields(fields):
    parsed = {}
    try:
        parsed["grid_voltage_v"] = int(fields[0]) / 10
        parsed["grid_freq_hz"] = int(fields[1]) / 10
        parsed["output_voltage_v"] = int(fields[2]) / 10
        parsed["output_freq_hz"] = int(fields[3]) / 10
        parsed["apparent_power_va"] = int(fields[4])
        parsed["active_power_w"] = int(fields[5])
        parsed["load_percent"] = int(fields[6])
        parsed["battery_voltage_v"] = int(fields[7]) / 10
    except:
        pass

    try: parsed["batt_charge_current_a"] = int(fields[11])
    except: pass
    try: parsed["battery_soc_percent"] = int(fields[12])
    except: pass
    try: parsed["inverter_temp_c"] = int(fields[13])
    except: pass
    try: parsed["batt_charge_current_mirror_a"] = int(fields[14])
    except: pass
    try: parsed["batt_discharge_current_a"] = int(fields[15])
    except: pass

    try: parsed["pv_power_w"] = int(fields[16])
    except: pass
    try: parsed["pv1_voltage_v"] = int(fields[18]) / 10
    except: pass
    try: parsed["pv_current_candidate"] = int(fields[19])
    except: pass

    # --- Battery power calculations ---
    try:
        vbat = parsed.get("battery_voltage_v", 0)
        charge_a = parsed.get("batt_charge_current_a", 0)
        discharge_a = parsed.get("batt_discharge_current_a", 0)

        # Signed combined power
        if charge_a and charge_a > 0:
            parsed["battery_power_w"] = vbat * charge_a
        elif discharge_a and discharge_a > 0:
            parsed["battery_power_w"] = -vbat * discharge_a
        else:
            parsed["battery_power_w"] = 0

        # Explicit charge/discharge powers
        parsed["battery_charge_power_w"] = vbat * charge_a if charge_a > 0 else 0
        parsed["battery_discharge_power_w"] = vbat * discharge_a if discharge_a > 0 else 0

    except Exception as e:
        parsed["battery_power_error"] = str(e)

    # --- Flags ---
    try:
        flags = fields[20:28]
        parsed["flags_raw"] = flags

        raw_export = flags[7]
        clean_export = ''.join(ch for ch in raw_export if ch.isdigit())

        parsed["flags_decoded"] = {
            "grid_ok": (flags[0] == "0"),
            "mode": MODE_MAP.get(int(flags[1]), f"Unknown({flags[1]})"),
            "alarm": (flags[2] != "0"),
            "battery_present": (flags[4] != "0"),
            "charging_enabled": (flags[5] != "0"),
            "load_active": (flags[6] != "0"),
            "export_policy": EXPORT_POLICY_MAP.get(int(clean_export) if clean_export else -1,
                                                  f"Unknown({raw_export})"),
        }
    except Exception as e:
        parsed["flags_error"] = str(e)

    return parsed

# --- MQTT setup ---
#client = mqtt.Client()
client = mqtt.Client(protocol=mqtt.MQTTv311)
client.username_pw_set(MQTT_USER, MQTT_PASS)
client.connect(MQTT_BROKER, MQTT_PORT, 60)

def publish_data(raw, parsed):
    timestamp = datetime.now(timezone.utc).isoformat()

    client.publish(f"{MQTT_BASE_TOPIC}/raw", json.dumps({
        "timestamp": timestamp,
        "reply": raw
    }), qos=0, retain=False)

    for k, v in parsed.items():
        if isinstance(v, dict):
            for fk, fv in v.items():
                client.publish(f"{MQTT_BASE_TOPIC}/{k}/{fk}", str(fv))
        else:
            client.publish(f"{MQTT_BASE_TOPIC}/{k}", str(v))

# --- Main loop ---
def main():
    while True:
        try:
            reply = poll_inverter()
            fields = reply.split(",")
            parsed = parse_fields(fields)
            publish_data(reply, parsed)
        except Exception as e:
            print("Error:", e)
        client.loop(0)
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()
